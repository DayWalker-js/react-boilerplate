import React, {PureComponent} from 'react';
import './style.scss';
import pluralize from "pluralize-ru";


export default  class Product extends PureComponent{

    constructor(props) {
        super(props)

        this.state = {
            available: true,
            selected: false
        }
    }

    componentWillUpdate() {
        console.log('will update')
    }


    render() {
        const {product} = this.props;
        const body = <div className="product-item"
                          data-availlable={this.state.available = product.available > 0 ? true : false}
                          data-selected={this.state.selected}
                          onClick = { () => {
                              product.available > 0 ?  this.setState(selected => ({
                                  selected: !this.state.selected
                              })) : false
                          }
                          }
        >
                        <div className="product-item-title">
                            <p>{product.title}</p>
                        </div>
                        <div className="product-item__description">
                            <h4>{product.name}</h4>
                            <h5>{product.nameDescription}</h5>
                            <p><strong>{product.qntPortions}</strong> {pluralize(product.qntPortions, 'порций', 'порция', 'порции', 'порций')}</p>
                            <p><strong>{product.qntPresent}</strong> {pluralize(product.qntPresent, 'порций', 'порция', 'порции', 'порций')} {product.descriptionPresent}</p>
                            <p>{(product.sentiment.length) ?  product.sentiment : null}</p>
                            <div className="product-item__image"><img src={product.imageUrl}/></div>
                        </div>
                    </div>
        return (
            <>
                {body}
                </>
        )
    }


}


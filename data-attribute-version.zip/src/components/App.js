import React, {PureComponent} from 'react';
import Productslist from "./Products/Productslist";
import products from "../data/products/products";
import './../styles/App.scss';

export default class App extends PureComponent {
    constructor(props) {
        super(props)
    }
    render(){
        return (

            <div className="products-container">
                <div className="products-container__center">
                    <div className="title-container">
                       Ты сегодня покормил кота?
                    </div>
                    <Productslist products = {products}/>

                </div>

            </div>
        )
    }
}


